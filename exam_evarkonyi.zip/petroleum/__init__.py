csv_yearly_production = "./petroleum/data/NorskPetroleum_aarlig_produksjon.csv"

from .petroleum_utility import *